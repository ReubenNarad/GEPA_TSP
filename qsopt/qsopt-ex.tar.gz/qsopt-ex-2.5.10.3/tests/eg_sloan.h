#ifndef __SLOAN_LP__
#define __SLOAN_LP__
#include <stdio.h>

#if OS == LINUX
#include <getopt.h>
#endif
#include "exact.h"
#endif
